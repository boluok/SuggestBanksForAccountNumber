import UIKit
extension String {
    func index(from: Int) -> Index {
        return self.index(startIndex, offsetBy: from)
    }
    
    func substring(from: Int) -> String {
        let fromIndex = index(from: from)
        return substring(from: fromIndex)
    }
    
    func substring(to: Int) -> String {
        let toIndex = index(from: to)
        return substring(to: toIndex)
    }
    
    func substring(with r: Range<Int>) -> String {
        let startIndex = index(from: r.lowerBound)
        let endIndex = index(from: r.upperBound)
        return substring(with: startIndex..<endIndex)
    }
}

func getNubanCode(cbncode:String)->Int{
    var numberCheck = 0
    var sum = 0
    for char in cbncode{
        switch numberCheck {
        case 0:
            if let number = Int(String(char)) {
                sum += number * 3
            }
            numberCheck+=1
        case 1:
            if let number = Int(String(char)) {
                sum += number * 7
            }
            numberCheck+=1
        case 2:
            if let number = Int(String(char)) {
                sum += number * 3
            }
            numberCheck=0
        default:
            print("Error")
        }
    }
    return sum
}

func getBank( fullbankList:Array<Bank>, accountNumber:String) -> Array<Bank>{
    
    var selectedBanksList = Array<Bank>()
    //Determine sum after each digit has been multiplied by "373" in sequence except the last digit
    let sumSample = accountNumber[0..<accountNumber.count-1]
    var numberCheck = 0
    var sum = 0
    
    for char in sumSample {
        switch numberCheck {
        case 0:
            if let number = Int(String(char)) {
               sum += number * 3
            }
            numberCheck+=1
        case 1:
            if let number = Int(String(char)) {
                sum += number * 7
            }
            numberCheck+=1
        case 2:
            if let number = Int(String(char)) {
                sum += number * 3
            }
            numberCheck=0
        default:
            print("Error")
    }
    }
    
    print(sum)
        
        for banks in fullbankList{
            if(!(banks.nubancode == "0")){
                let a = getNubanCode(cbncode: banks.nubancode) + sum
                let b = a % 10
                var check:Int
                if(b == 0){
                    check = 0
                }else{
                    check = 10 - b
                }
               
        
                let lastindex = accountNumber.substring(from: accountNumber.count-1)
                if(check == Int(lastindex)!){
                    selectedBanksList.append(banks)
                }
            }
        }
    
    return selectedBanksList
}

extension String {
    subscript(_ range: CountableRange<Int>) -> String {
        let idx1 = index(startIndex, offsetBy: max(0, range.lowerBound))
        let idx2 = index(startIndex, offsetBy: min(self.count, range.upperBound))
        return String(self[idx1..<idx2])
    }
}
class Bank{
    var bankname : String
    var bankcode :String
    var nubancode : String
    init(bankname:String,bankcode:String,nubancode:String) {
        self.bankcode = bankcode
        self.bankname = bankname
        self.nubancode = nubancode
    }
}
var bankList = Array<Bank>()
bankList.append(Bank(bankname: "Access Bank", bankcode: "000014", nubancode: "044"))
bankList.append(Bank(bankname: "Diamond Bank", bankcode: "000005", nubancode: "063"))
bankList.append(Bank(bankname: "Ecobank Bank", bankcode: "000014", nubancode: "050"))
bankList.append(Bank(bankname: "Fidelity Bank", bankcode: "000007", nubancode: "070"))
bankList.append(Bank(bankname: "FCMB", bankcode: "000003", nubancode: "214"))
bankList.append(Bank(bankname: "First Bank of Nigeria", bankcode: "000016", nubancode: "011"))
bankList.append(Bank(bankname: "GTBank Plc", bankcode: "000013", nubancode: "058"))
bankList.append(Bank(bankname: "Heritage", bankcode: "000020", nubancode: "030"))
bankList.append(Bank(bankname: "Keystone Bank", bankcode: "000002", nubancode: "082"))
bankList.append(Bank(bankname: "Polaris Bank", bankcode: "000008", nubancode: "076"))
bankList.append(Bank(bankname: "StanbicIBTC Bank", bankcode: "000002", nubancode: "082"))
bankList.append(Bank(bankname: "Polaris Bank", bankcode: "000012", nubancode: "221"))
bankList.append(Bank(bankname: "United Bank for Africa", bankcode: "000004", nubancode: "033"))
bankList.append(Bank(bankname: "Wema Bank", bankcode: "000017", nubancode: "035"))
bankList.append(Bank(bankname: "Zenith Bank", bankcode: "000015", nubancode: "057"))



let choosenbanklist = getBank(fullbankList: bankList, accountNumber: "3091484502")

for banks in choosenbanklist{
    print(banks.bankname)
}









